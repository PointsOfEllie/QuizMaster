﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuizMaster.DataContext;
using QuizMaster.DataContext.Entities;
using QuizMaster.UI.Models;

namespace QuizMaster.UI.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizMasterDataContext quizMasterDataContext;

        public HomeController(QuizMasterDataContext quizMasterDataContext)
        {
            this.quizMasterDataContext = quizMasterDataContext;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            // do not do this in live code
            //var newQuiz = new Quiz
            //{
            //    QuizName = "Third Quiz",
            //    Description = "My description"
            //};

            //for (int i = 0; i < 4; i++)
            //{
            //    var question = new Question
            //    {
            //        QuestionText = $"Question {i}",
            //        QuizId = newQuiz.Id
            //    };
            //    newQuiz.Questions.Add(question);
            //}
            //quizMasterDataContext.Quizzes.Add(newQuiz);

            //quizMasterDataContext.SaveChanges();

            var quiz = quizMasterDataContext.Quizzes.Include(x => x.Questions).FirstOrDefault(x => x.Id == 3);
           
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
