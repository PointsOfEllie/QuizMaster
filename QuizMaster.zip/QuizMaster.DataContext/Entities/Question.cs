﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace QuizMaster.DataContext.Entities
{
    [Table("Question")]
    public class Question
    {
        public int Id { get; set; }

        public int QuizId { get; set; }

        public string QuestionText { get; set; }
    }
}
