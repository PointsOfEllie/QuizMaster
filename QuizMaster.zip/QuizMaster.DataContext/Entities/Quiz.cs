﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace QuizMaster.DataContext.Entities
{
    [Table("Quiz")]
    public class Quiz
    {
        public Quiz()
        {
            Questions = new List<Question>();
        }
        //[Key]
        public int Id { get; set; }

        public string QuizName { get; set; }

        public string Description { get; set; }


        public virtual List<Question> Questions { get; set; }

    }
}
