﻿using Microsoft.EntityFrameworkCore;
using QuizMaster.DataContext.Entities;
using System;

namespace QuizMaster.DataContext
{
    public class QuizMasterDataContext : DbContext
    {
        public QuizMasterDataContext(DbContextOptions<QuizMasterDataContext> options) : base(options)
        {
        }

        public DbSet<Quiz> Quizzes { get; set; }

        public DbSet<Question> Questions { get; set; }
    }
}
