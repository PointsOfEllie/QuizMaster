﻿CREATE TABLE [dbo].[Question]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuizId] INT NOT NULL, 
	[QuestionText] VARCHAR(100) NOT NULL,
    CONSTRAINT [FK_Question_Quiz] FOREIGN KEY ([QuizId]) REFERENCES [Quiz]([Id])
)
